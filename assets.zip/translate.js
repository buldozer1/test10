var new_lang = {

    "lt0": "Moda",

    "lt1": "Noticias",

    "lt2": "Otros temas:",

    "lt3": "Meghan Markle",

    "lt4": "Guía Shopping",

    "lt5": "Looks Realeza",

    "lt6": "Fashion Week Madrid",

    "lt7": "Tendencias",

    "lt8": "Modelos",

    "lt9": "Pasarelas",

    "lt10": "Noticias",

    "lt11": "Especial colecciones",

    "lt12": "All about Eu",

    "lt13": "Guía de moda",

    "lt14": "H!FASHION",

    "lt15": "Cerrar",

    "lt16": "Secciones",

    "lt17": "Portada",

    "lt18": "Actualidad",

    "lt19": "Moda",

    "lt20": "Tendencias",

    "lt21": "Modelos",

    "lt22": "Noticias",

    "lt23": "Pasarelas",

    "lt24": "Complementos",

    "lt25": "Belleza",

    "lt26": "Noticias",

    "lt27": "Tendencias",

    "lt28": "Cara y cuerpo",

    "lt29": "Peinados",

    "lt30": "Perder Peso",

    "lt31": "En Forma",

    "lt32": "LifeStyle",

    "lt33": "Decoración",

    "lt34": "Cocina",

    "lt35": "Recetas",

    "lt36": "Noticias",

    "lt37": "Técnicas de cocina",

    "lt38": "Comunidad blogs",

    "lt39": "Estar bien",

    "lt40": "Nutrición",

    "lt41": "Bienestar",

    "lt42": "Mascotas",

    "lt43": "Medio ambiente",

    "lt44": "Psicología",

    "lt45": "Coaching",

    "lt46": "Vida Sana",

    "lt47": "Enfermedades",

    "lt48": "Novias",

    "lt49": "Ser Madre",

    "lt50": "Viajes",

    "lt51": "Destinos",

    "lt52": "Hoteles",

    "lt53": "Casas Reales",

    "lt54": "Bélgica",

    "lt55": "Dinamarca",

    "lt56": "España",

    "lt57": "Holanda",

    "lt58": "Liechtenstein",

    "lt59": "Luxemburgo",

    "lt60": "Mónaco",

    "lt61": "Noruega",

    "lt62": "Reino Unido",

    "lt63": "Suecia",

    "lt64": "tuotrodiario",

    "lt65": "Horóscopo",

    "lt66": "Blogs",

    "lt67": "¡HOLA! Fashion",

    "lt68": "¡HOLA! En forma",

    "lt69": "Buscar",

    "lt70": "HOME",

    "lt71": "/",

    "lt72": "Moda",

    "lt73": "/",

    "lt74": "Noticias",

    "lt75": "¡La presentadora Carlota Corredera ha contado el secreto de cómo ha perdido 60 kilos de peso exceso!",

    "lt76": "En 2018, Carlota Corredera ha asombrado a la sociedad ¡al haber perdido 60 kilos! Ahora Carlota continúa siguiendo el programa de perdida de peso.",

    "lt77": "<script type=\"text/javascript\">var d=new Date(new Date().getTime() - 24 * 60 * 60 * 2000);var day=d.getDate();var month=d.getMonth() + 1;var year=d.getFullYear();document.write(day + \".\" + month + \".\" + year);</script>12.6.2019 - 19:12 CET",

    "lt78": "by",

    "lt79": "hola.com",

    "lt80": "Comentar",

    "lt81": "Primeramente, después de adelgazar tanto, la presentadora no decía las razones verdaderas de perder tantos kilos, solo hablaba de una dieta especial. Pero Carlota ha confesado a nuestro periodista y ha contado la razón verdadera de su adelgazamiento. En este artículo se escribe toda la historia de Carlota: cómo ella adelgazó, pero luego ganó de peso otra vez, y ¡cómo ella ha vuelto al peso y el cuerpo sanos hoy!",

    "lt82": "La historia del peso exceso",

    "lt83": "Carlota ha trabajado de presentadora televisiva a partir de 2011, toda la gente del país ama los programas que ella presenta. La chica tiene la propensidad a la obesidad, y ya en aquel entonces ella era corpulenta y le gustaba comer productos poco sanos a no decir malos.",

    "lt84": "A la razón de peso exceso su carrera iba mal, los kilos de más le impedían desarrollarse, las reseñas empezaban a ser más y más negativas, con consejos de ¡«perder peso o dejar el trabajo»!",

    "lt85": "El punto de cambio de la historia de peso exceso fue el embarazo de la presentadora. Aun planeando el embarazo, Carlota encaró el problema de ganar mucho peso.",

    "lt86": "«Para dejarme embarazada, dejé de fumar… En vez de fumar mucho comencé a comer mucho más. No podía controlar mi peso, lo ganaba cada día sin parar...»",

    "lt87": "Con el embarazo la situación se empeoró. Carlota vestía la talla 60, ¡y pesaba 128 kilos! Luego Carlota dijo a los periodistas, que los problemas de pesar mucho ella ya tenía de adolescente, la representadora no podía superar la muerte de su padre y se consolaba con la comida. Ella parecía una chica joven y alegre, pero tenía muchos complejos por dentro. Después de tener su primogénito, tenía que meter su cuerpo en forma.",

    "lt88": "Pasaba todo el tiempo libre haciendo ejercicios agotadores en el gimnasio, consultaba con un nutricionista, y ¡logró perder los 60 kilos! Ella logró el peso ideal con muchos fuerzos y dolores, luego publicó su libro «Tú también puedes: cómo conseguí perder 60 kilos y ganar salud», que fue el hit de ventas en Europa.",

    "lt89": "Volver a problemas",

    "lt90": "Los terapéutas confirman que el peso exceso nunca se va para siempre y en el 75% de los casos vuelve cuando las personas pierden su motivación. Eso fue que pasó a Carlota. En unos años ella no solo ganó todos los kilos perdidos ¡sino también ganó 13 kilos más!",

    "lt91": "La gente ya no creía a ella y a sus libros, y las reseñas eran muy negativas de ella y de su trabajo. Los espectadores querían que ella se fuera por volver a parecer una mujer no sexual. Las ventas de sus libros se bajaron, cuando Carlota dejó de ocultar sus problemas de peso exceso. Ya nadie quería creer en el programa miracoloso escrito por una mujer que no logró obtener un cuerpo ideal.",

    "lt92": "«Tu método es una estafa: escribían en Instagram. Siempre me atacaban, yo estaba muy estresada y continuaba comiendo con exceso…»",

    "lt93": "Los infortunios continuaban sucediendo dos años más, la chica tenía problemas de salud y el peso muy exceso.",

    "lt94": "A un paso de la muerte",

    "lt95": "En 2016, a Carlota diagnosticaron la obesidad del primer grado con un alto riesgo de las enfermedades cardiovasculares.",

    "lt96": "«Hice esta foto cuando decidí que no quería más vivir en este cuerpo. Decidí deshacerme del peso exceso una vez por todas, para no perder mi carrera y vivir una vida sana…»",

    "lt97": "Primero Carlota ayunaba, luego volvía a comer mucho y se odiaba.",

    "lt98": "Deporte, altas cargas, y ejercicios agotadores no le hacían bien, y no daban ningunos resultados. Carlota necesitaba un método potente de perder peso.",

    "lt99": "Carlota se dirigió a un cirujano de liposucción, al mejor especialista en su campo en aquel entonces. Ella decidió operarse, pero después de todos los analisis era claro que existían muchos riesgos de perder la vida.",

    "lt100": "En cambio, el cirujano le prescribió Reduslim, que era en aquel entonces una novedad en el mercado español entre los fármacos para curar la obesidad sin operarse.",

    "lt101": "Camino a la vida sana",

    "lt102": "Los primeros resultados aparecieron en la primera semana del uso. ¡La figura empezó a cambiarse! Reduslim aceleró muy rápido el metabolismo de Carlota y empezó a quemar las grasas. ¡Los primeros éxistos asombraron a los espectadores! Muchos se interesaron ¡cómo ella consiguió adelgazar!",

    "lt103": "«No quería abrir mi secreto, pero al perder 15 kilos ya no podía ocultar que usaba el fármaco especial para perder peso. Se llama Reduslim, él hizo mi figura ideal sin deporte y dietas. Todo el país supo de él.»",

    "lt104": "El fármaco Reduslim es especial porque inicia el proceso de quemar las grasas en un instante. Independientemente, si haces dietas o deporte, o no haces nada – las grasas se convierten en energía y se desgasta durante el día. Al tomarse el fármaco, cada día se pierden de 300 a 500 gramos de peso exceso.",

    "lt105": "Reduslim para perder peso. Ayuda a perder peso exceso en corto plazo sin consecuencias graves para el cuerpo. No es un medicamento. Es un complemento alimentario biológico.",

    "lt106": "Reduslim para perder peso es un fármaco potente que quema grasas y garantiza:",

    "lt107": "eliminar los depósitos de grasas.",

    "lt108": "normalizar el metabolismo.",

    "lt109": "normalizar el apetito.",

    "lt110": "reitrar el colesterol «malo» y los radicales libres del cuerpo.",

    "lt111": "eliminar hinchazones y prevenirlos.",

    "lt112": "acelerar la digestión.",

    "lt113": "hacer la piel elástica al renovar las células.",

    "lt114": "prevenir los nuevos depósitos de grasas.",

    "lt115": "No es obligatorio tomárselo siempre, basta hacer un curso ¡para obtener el peso ideal para siempre!",

    "lt116": "«No quiero volver al peso exceso del que sufría tanto. Continúo tomando Reduslim para mantenerme en forma y comer todo lo que quiero. Hoy puedo decir que estoy contenta con mi cuerpo.»",

    "lt117": "Se puede pedir el fármaco solo en el sitio oficial ¡para evitar los falsos y garantizar el efecto!",

    "lt118": "Pedir",

    "lt119": "Comentarios",

    "lt120": "Lucía Avila",

    "lt121": "Muchas gracias. Es muy interesante. He pedido<strong>Reduslim</strong>. El nutricionista me comunicó que existe una gran demanda, pero todavía tienen muchos. Se venden muy rápidamente.",

    "lt122": "Ana Morales",

    "lt123": "Mi amiga vive en Bulgaria. Me ha contado de este fármaco. Lo usan muchos en su país.",

    "lt124": "Natalia Martínez",

    "lt125": "Guau, qué interesante. Vaya suerte. He pedido 2 confecciones, quiero hacer un curso para perder todo el peso exceso.",

    "lt126": "Laura Gómez",

    "lt127": "<strong>«Reduslim»</strong>– ¡es una cosa verdaderamente muy buena! Yo siempre he sido corpulenta. No esperaba perder peso algún día pero gracia a <strong>«Reduslim»</strong>¡¡¡perdí 34 kilos!!!! Me siento mucho mejor, no tengo enfermedades de obesidad. Se lo aconsejo. ¡Salva literalmente!",

    "lt128": "Vicky Palmas",

    "lt129": "A la razón de peso exceso tenía hipertonía y las articulaciones doloridas. Mi médico aconsejó hacer el curso de<strong>«Reduslim»</strong>. Perdí 26 kilos en 2 meses.",

    "lt130": "Marta Bravas",

    "lt131": "¡Es una cosa genial que mola! Me lo tomo solo 5 días, y ya he perdido 4 kilos. No hago nada más, solo Reduslim. Pierdo peso automáticamente.",

    "lt132": "Lora Carnoso",

    "lt133": "¡Me lo quiero pedir! Espero que almacén no se acabe, voy a pedir ahora mismo. No me lo puedo creer que un remedio miracoloso tengo un precio tan bajo y ¡funcione bien!",

    "lt134": "Marta Santos Noja",

    "lt135": "He perdido 20 kilos. Además corría e iba al gimnasio, porque tenía energía de sobra. Ahora estoy muy delgada con la piel elástica. Cada día los chicos me hacen piropos, antes ni siquiera me miraban. Es muy agradable",

    "lt136": "Inés Valenciana",

    "lt137": "Todas mis amigas están hablando sobre este<strong>«Reduslim»</strong>. Ayudó a perder peso a muchas de ellas. Es un verdadero hit",

    "lt138": "Susana Calmas",

    "lt139": "¡Adoro a esta presentadora! Al leer el artículo, he pedido<strong>Reduslim</strong>. Ayer lo recibí. Empecé a tomarlo. ¡El remedio y el paco se ven muy bien!",

    "lt140": "Anita Amo",

    "lt141": "Pronto me voy a casar. Debo adelgazar. Espero que el fármaco funcione de verdad. No sabía que ahora se vende a un precio muy bueno, quería comprármelo desde hace mucho.",

    "lt142": "Jorge Vargas",

    "lt143": "Mi mujer adelgazó con este<strong>Reduslim</strong>. Me pareció gracioso, porque antes no le había ayudado nada... Pero el resultado ha sido genial. Admito no haber tenido razón. Ella se ve y se siente muy bien. ¡También voy a probarlo!",

    "lt144": "Alba Llosa",

    "lt145": "Todo el mundo está hablando de<strong>“Reduslim”</strong>. He leído muchas reseñas. Quiero probarlo, además tienen una oferta muy buena",

    "lt146": "Luz López",

    "lt147": "¡¡¡Yo he adelgazado!!!! Perdí 18 kilos en 6 semanas. No he tenido tal resultado nunca antes. ¡¡¡Muchas gracias por el artículo!!!",

    "lt148": "Julia Piedras",

    "lt149": "¡¡Muchas gracias!!",

    "lt150": "Pedir",

    "lt151": "© ¡HOLA! Prohibida la reproducción total o parcial de este reportaje y sus fotografías, aun citando su procedencia.",

    "lt152": "Recomendamos",

    "lt153": "Sara vs. Chiara: dos iconos, dos formas de ver la moda",

    "lt154": "Los mejores destinos del mundo para hacer snorkel ¿Sabías que solo conocemos un 5% de todo lo que esconde el mar?",

    "lt155": "Se llaman 'Bohemian Vuittony' y son la gran tendencia del verano en gafas de sol",

    "lt156": "Últimas Noticias",

    "lt157": "Acabados metalizados: la última tendencia para el diseño de la cocina",

    "lt158": "¿Ha elegido el peinado de su boda? Esto es lo que nos ha contado el peluquero de Pilar Rubio",

    "lt159": "El regalo que el príncipe Harry entregó a Meghan en su primer aniversario",

    "lt160": "El enigmático post en Instagram de Sara Carbonero tras su nuevo ingreso",

    "lt161": "Un traje rosa y rebajado: la apuesta de Melania para su último duelo de estilo",

    "lt162": "Si conoces estos lugares puedes decir que eres un experto en Dinamarca",

    "lt163": "De Carlota a Candela: los botines son el accesorio sorpresa de las novias de primavera",

    "lt164": "Más sobre:",

    "lt165": "Carlota Corredera",

    "lt166": "Sálvame",

    "lt167": "Cámbiame",

    "lt168": "Telecinco",

    "lt169": "Más noticias sobre<a href=\"{url}\">Carlota Corredera</a>",

    "lt170": "'Sálvame' cumple diez años: así han cambiado los colaboradores",

    "lt171": "Carlota Corredera explica cómo se está recuperando Terelu Campos de su última operación",

    "lt172": "Carlota Corredera se lanza y da el nombre de su favorito para ganar 'GH Dúo'",

    "lt173": "Últimos comentarios",

    "lt174": "Escribe tu comentario:",

    "lt175": "Vas a responder a<span id=\"cmtCmtNombre\"></span>, si lo prefieres,",

    "lt176": "Comenta en la noticia",

    "lt177": "Esta es la opinión de los internautas, no la de hola.com. No está permitido verter comentarios contrarios a las leyes españolas o injuriantes.<br>Nos reservamos el derecho a eliminar los comentarios que consideremos fuera de tema",

    "lt178": "Para poder comentar necesita ser usuario registrado de hola.com",

    "lt179": "Regístrate para comentar",

    "lt180": "Portada de hola.com, tu revista en internet",

    "lt181": "© 2000-2019, HOLA S.L.",

    "lt182": "Enlaces corporativos",

    "lt183": "Boletines y alertas",

    "lt184": "Publicidad",

    "lt185": "SUSCRIPCIONES",

    "lt186": "Advertencia legal",

    "lt187": "Política de cookies",

    "lt188": "Publicación controlada<strong>OJD</strong>",

    "lt189": "Archivo",

    "lt190": "Estamos en contacto",

    "lt191": "Pulse aquí para suscribirse al rss de hola.com",

    "lt192": "Síguenos en twitter",

    "lt193": "Síguenos en Pinterest",

    "lt194": "Síguenos en facebook",

    "lt195": "Canal Youtube de hola.com",

    "lt196": "Contacto",

    "lt197": "Ir a inicio",

    "lt198": "Buscar",

    "lt199": "INICIA SESIÓN",

    "lt200": "Salir",

    "lt201": "SUSCRIPCIONES",

    "lt202": "Síguenos en facebook",

    "lt203": "Síguenos en twitter",

    "lt204": "Síguenos en Instagram",

    "lt205": "Síguenos en Pinterest",

    "lt206": ".scrollDown .news-share {transition: top .3s ease-out;}#top-banner iframe body {text-align: center;}",

    "lt207": "España"
};

function Translater() {
    for (class_name in new_lang) {
        var elements = document.getElementsByClassName(class_name);
        if (elements.length) {
            for (key in elements) {
                elements[key].innerHTML = new_lang[class_name];
            }
        }
    }
};